# Length justification

*For the "Comments to the Editor" field at submission, per the JSS Guide for Authors: "It is
encouraged that authors submit full-length papers of less than 36 pages single-column… If your
manuscript is longer, please include an explanation in your submission as to why the length is
justified."*

---

The manuscript runs to **30 single-column pages** in the `elsarticle` preprint class, including all
declarations and the reference list (101 entries), well within the recommended limit of 36 pages. No special
length justification is required.

The body maintains each headline result with the empirical evidence needed to inspect it (13 tables, 6 figures).
Secondary analyses, derivations, and protocol details are organized into:
- **Supplementary Material (S1–S35):** sensitivity sweeps, AHP pairwise comparison matrices and consistency proofs,
  corpus parameters and composition, the feature schema, anti-pattern and attention analyses, convergent validity,
  in-distribution results, active-stratum and bootstrap tables, the registered GPU LOSO sweep, gate-vs-oracle
  cost breakdowns, the full predictor taxonomy, per-fold hybrid results,
  and the registration amendment log with the omnibus Holm correction.
- **Public experiment pages** (`docs/research/jss/experiments/` at the submission tag): protocols,
  hyperparameters, reproduction commands, and artifact names for every experiment.

Every table value across both documents is mechanically reconciled against the artifact that produced it.
